import { Component } from '@angular/core';

@Component({
  selector: 'app-striped-rows',
  templateUrl: './striped-rows.component.html',
  styleUrls: ['./striped-rows.component.scss']
})
export class StripedRowsComponent {
}
